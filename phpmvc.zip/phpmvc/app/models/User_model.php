<?php 

class User_model {
    private $nama = 'ZAHRA NURANIDA';

    public function getUser()
    {
        return $this->nama;
    }
}